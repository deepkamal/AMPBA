import scrapy

class AmazonBooksSpider(scrapy.Spider):
   #name of spider
   name = 'amazonBooks'

   #list of allowed domains
   allowed_domains = ['www.amazon.in/s?k=books']
   #starting url
   start_urls = ['https://www.amazon.in/s?k=books']
   #location of csv file
   custom_settings = {
       'FEED_URI' : 'tmp/amazonBooks.csv'
   }

   def parse(self, response):
       #Extract product information
       titles=response.css('div[class="a-section aok-relative s-image-fixed-height"]').css('img::attr(alt)').extract() 
       images=response.css('div[class="a-section aok-relative s-image-fixed-height"]').css('img::attr(src)').extract() 
       titles2=response.css('span[class="a-size-medium a-color-base a-text-normal"]::text').extract() 
       authors=response.css('a[class="a-size-base a-link-normal"]::text').extract()

       for item in zip(titles,titles2,images,authors):
           scraped_info = {
               'title' : item[0],
               'price' : item[1],
               'image_urls' : [item[2]], #Set's the url for scrapy to download images
               'discount' : item[3]
           }

           yield scraped_info