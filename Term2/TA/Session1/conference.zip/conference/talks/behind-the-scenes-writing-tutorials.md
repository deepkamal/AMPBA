title: 'Behind the scenes: writing tutorials'
subtitle:
speaker: emmanuelle-delescolle
---
There are many ways to contribute to OpenSource, writing code is only one of them. Sadly writing code is often the only one which is recognized as valuable.
Among the many ways you can contribute to OpenSource, one is writing tutorials, books, workshop or class lessons. In short different ways to spread knowledge. But what constitute the process of building such resources?