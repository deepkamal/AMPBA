title: 'Using Python for National Cipher Challenge'
subtitle:
speaker: thomas-campbell
---
The National Cipher Challenge is run by The University of Southampton every year and invites people to break ciphers of varying difficulty, from simple Caesar ciphers to Enigma and beyond. In this talk, I’ll describe how I used python to tackle the 2015 challenge and demonstrate some of the code I used in doing so.