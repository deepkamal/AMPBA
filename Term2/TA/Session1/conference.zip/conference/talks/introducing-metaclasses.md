title: 'Introducing MetaClasses'
subtitle:
speaker: amit-kumar
---
This talk is based on the metaclasses in Python. The secret sauce which create classes.