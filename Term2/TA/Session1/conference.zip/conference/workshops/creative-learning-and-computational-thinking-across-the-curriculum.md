speaker: kath-morton-smith
title: Creative learning and computational thinking across the curriculum
---
This session will be about how new pedagogic practices in education are nothing new in the creative and tech industries, and how a mind shift towards computational thinking and creative learning will help teachers role out the new Digital Competence Framework. The session will include anecdotes from my time teaching media and video production and running after school coding clubs, videos and samples of how to code with beginners in the classroom. 
